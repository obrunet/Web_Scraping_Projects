
# Stats from the scraped Pokemon's database
credits : https://pokemondb.net/


```python
import re
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings("ignore")
pd.options.display.max_columns = 40
```


```python
df = pd.read_csv('pokemon_db.csv', sep=";")
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id_nb</th>
      <th>name</th>
      <th>type_1</th>
      <th>type_2</th>
      <th>link</th>
      <th>data_species</th>
      <th>data_height</th>
      <th>data_weight</th>
      <th>data_abilities</th>
      <th>training_catch_rate</th>
      <th>training_base_exp</th>
      <th>training_growth_rate</th>
      <th>breeding_gender</th>
      <th>stats_hp</th>
      <th>stats_attack</th>
      <th>stats_defense</th>
      <th>stats_sp_atk</th>
      <th>stats_sp_def</th>
      <th>stats_speed</th>
      <th>stats_total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>#001</td>
      <td>Bulbasaur</td>
      <td>Grass</td>
      <td>Poison</td>
      <td>/pokedex/bulbasaur</td>
      <td>Seed Pokémon</td>
      <td>0.7</td>
      <td>6.9</td>
      <td>Overgrow</td>
      <td>45</td>
      <td>64</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>45</td>
      <td>49</td>
      <td>49</td>
      <td>65</td>
      <td>65</td>
      <td>45</td>
      <td>318</td>
    </tr>
    <tr>
      <th>1</th>
      <td>#002</td>
      <td>Ivysaur</td>
      <td>Grass</td>
      <td>Poison</td>
      <td>/pokedex/ivysaur</td>
      <td>Seed Pokémon</td>
      <td>1.0</td>
      <td>13.0</td>
      <td>Overgrow</td>
      <td>45</td>
      <td>142</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>60</td>
      <td>62</td>
      <td>63</td>
      <td>80</td>
      <td>80</td>
      <td>60</td>
      <td>405</td>
    </tr>
    <tr>
      <th>2</th>
      <td>#003</td>
      <td>Venusaur</td>
      <td>Grass</td>
      <td>Poison</td>
      <td>/pokedex/venusaur</td>
      <td>Seed Pokémon</td>
      <td>2.0</td>
      <td>100.0</td>
      <td>Overgrow</td>
      <td>45</td>
      <td>236</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>80</td>
      <td>82</td>
      <td>83</td>
      <td>100</td>
      <td>100</td>
      <td>80</td>
      <td>525</td>
    </tr>
    <tr>
      <th>3</th>
      <td>#004</td>
      <td>Charmander</td>
      <td>Fire</td>
      <td>Nan</td>
      <td>/pokedex/charmander</td>
      <td>Lizard Pokémon</td>
      <td>0.6</td>
      <td>8.5</td>
      <td>Blaze</td>
      <td>45</td>
      <td>62</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>39</td>
      <td>52</td>
      <td>43</td>
      <td>60</td>
      <td>50</td>
      <td>65</td>
      <td>309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>#005</td>
      <td>Charmeleon</td>
      <td>Fire</td>
      <td>Nan</td>
      <td>/pokedex/charmeleon</td>
      <td>Flame Pokémon</td>
      <td>1.1</td>
      <td>19.0</td>
      <td>Blaze</td>
      <td>45</td>
      <td>142</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>58</td>
      <td>64</td>
      <td>58</td>
      <td>80</td>
      <td>65</td>
      <td>80</td>
      <td>405</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.id_nb = df.id_nb.apply(lambda x: int(x.replace('#', '')))
df.set_index('id_nb', inplace=True)
```


```python
df.shape
```




    (809, 19)




```python
df.duplicated().sum()
```




    0




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 809 entries, 1 to 809
    Data columns (total 19 columns):
    name                    809 non-null object
    type_1                  809 non-null object
    type_2                  809 non-null object
    link                    809 non-null object
    data_species            809 non-null object
    data_height             809 non-null float64
    data_weight             809 non-null float64
    data_abilities          809 non-null object
    training_catch_rate     809 non-null object
    training_base_exp       809 non-null object
    training_growth_rate    809 non-null object
     breeding_gender        809 non-null object
    stats_hp                809 non-null int64
    stats_attack            809 non-null int64
    stats_defense           809 non-null int64
    stats_sp_atk            809 non-null int64
    stats_sp_def            809 non-null int64
    stats_speed             809 non-null int64
    stats_total             809 non-null int64
    dtypes: float64(2), int64(7), object(10)
    memory usage: 126.4+ KB



```python
df.rename(columns={' breeding_gender':'breeding_gender'}, inplace=True)
```

# Cleaning the data set


```python
df['percentages'] = df.breeding_gender.apply(lambda x: (re.findall("\d+\.\d+", x)))
df.data_species = df.data_species.apply(lambda x: x.replace('Pokémon', '').replace(' ', ''))
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>type_1</th>
      <th>type_2</th>
      <th>link</th>
      <th>data_species</th>
      <th>data_height</th>
      <th>data_weight</th>
      <th>data_abilities</th>
      <th>training_catch_rate</th>
      <th>training_base_exp</th>
      <th>training_growth_rate</th>
      <th>breeding_gender</th>
      <th>stats_hp</th>
      <th>stats_attack</th>
      <th>stats_defense</th>
      <th>stats_sp_atk</th>
      <th>stats_sp_def</th>
      <th>stats_speed</th>
      <th>stats_total</th>
      <th>percentages</th>
    </tr>
    <tr>
      <th>id_nb</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>805</th>
      <td>Stakataka</td>
      <td>Rock</td>
      <td>Steel</td>
      <td>/pokedex/stakataka</td>
      <td>Rampart</td>
      <td>5.5</td>
      <td>820.0</td>
      <td>Beast Boost</td>
      <td>30</td>
      <td>257</td>
      <td>Slow</td>
      <td>Genderless</td>
      <td>61</td>
      <td>131</td>
      <td>211</td>
      <td>53</td>
      <td>101</td>
      <td>13</td>
      <td>570</td>
      <td>[]</td>
    </tr>
    <tr>
      <th>806</th>
      <td>Blacephalon</td>
      <td>Fire</td>
      <td>Ghost</td>
      <td>/pokedex/blacephalon</td>
      <td>Fireworks</td>
      <td>1.8</td>
      <td>13.0</td>
      <td>Beast Boost</td>
      <td>30</td>
      <td>257</td>
      <td>Slow</td>
      <td>Genderless</td>
      <td>53</td>
      <td>127</td>
      <td>53</td>
      <td>151</td>
      <td>79</td>
      <td>107</td>
      <td>570</td>
      <td>[]</td>
    </tr>
    <tr>
      <th>807</th>
      <td>Zeraora</td>
      <td>Electric</td>
      <td>Nan</td>
      <td>/pokedex/zeraora</td>
      <td>Thunderclap</td>
      <td>1.5</td>
      <td>44.5</td>
      <td>Volt Absorb</td>
      <td>3</td>
      <td>270</td>
      <td>Slow</td>
      <td>Genderless</td>
      <td>88</td>
      <td>112</td>
      <td>75</td>
      <td>102</td>
      <td>80</td>
      <td>143</td>
      <td>600</td>
      <td>[]</td>
    </tr>
    <tr>
      <th>808</th>
      <td>Meltan</td>
      <td>Steel</td>
      <td>Nan</td>
      <td>/pokedex/meltan</td>
      <td>HexNut</td>
      <td>0.2</td>
      <td>8.0</td>
      <td>Magnet Pull</td>
      <td>—</td>
      <td>—</td>
      <td>—</td>
      <td>—</td>
      <td>46</td>
      <td>65</td>
      <td>65</td>
      <td>55</td>
      <td>35</td>
      <td>34</td>
      <td>300</td>
      <td>[]</td>
    </tr>
    <tr>
      <th>809</th>
      <td>Melmetal</td>
      <td>Steel</td>
      <td>Nan</td>
      <td>/pokedex/melmetal</td>
      <td>HexNut</td>
      <td>2.5</td>
      <td>800.0</td>
      <td>Iron Fist</td>
      <td>—</td>
      <td>—</td>
      <td>—</td>
      <td>—</td>
      <td>135</td>
      <td>143</td>
      <td>143</td>
      <td>80</td>
      <td>65</td>
      <td>34</td>
      <td>600</td>
      <td>[]</td>
    </tr>
  </tbody>
</table>
</div>




```python
col = df.columns
col
```




    Index(['name', 'type_1', 'type_2', 'link', 'data_species', 'data_height',
           'data_weight', 'data_abilities', 'training_catch_rate',
           'training_base_exp', 'training_growth_rate', 'breeding_gender',
           'stats_hp', 'stats_attack', 'stats_defense', 'stats_sp_atk',
           'stats_sp_def', 'stats_speed', 'stats_total', 'percentages'],
          dtype='object')




```python
for c in col:
    df.loc[(df[c] == 'Nan') | (df[c] == '—'), c] = np.nan
```


```python
df.isnull().sum()
```




    name                      0
    type_1                    0
    type_2                  404
    link                      0
    data_species              0
    data_height               0
    data_weight               0
    data_abilities            0
    training_catch_rate       2
    training_base_exp         2
    training_growth_rate      2
    breeding_gender           2
    stats_hp                  0
    stats_attack              0
    stats_defense             0
    stats_sp_atk              0
    stats_sp_def              0
    stats_speed               0
    stats_total               0
    percentages               0
    dtype: int64




```python
#Keep only the rows with at least 18 non-NA values.
df = df.dropna(thresh=18)
df.tail(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>type_1</th>
      <th>type_2</th>
      <th>link</th>
      <th>data_species</th>
      <th>data_height</th>
      <th>data_weight</th>
      <th>data_abilities</th>
      <th>training_catch_rate</th>
      <th>training_base_exp</th>
      <th>training_growth_rate</th>
      <th>breeding_gender</th>
      <th>stats_hp</th>
      <th>stats_attack</th>
      <th>stats_defense</th>
      <th>stats_sp_atk</th>
      <th>stats_sp_def</th>
      <th>stats_speed</th>
      <th>stats_total</th>
      <th>percentages</th>
    </tr>
    <tr>
      <th>id_nb</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>806</th>
      <td>Blacephalon</td>
      <td>Fire</td>
      <td>Ghost</td>
      <td>/pokedex/blacephalon</td>
      <td>Fireworks</td>
      <td>1.8</td>
      <td>13.0</td>
      <td>Beast Boost</td>
      <td>30</td>
      <td>257</td>
      <td>Slow</td>
      <td>Genderless</td>
      <td>53.0</td>
      <td>127.0</td>
      <td>53.0</td>
      <td>151.0</td>
      <td>79.0</td>
      <td>107.0</td>
      <td>570.0</td>
      <td>[]</td>
    </tr>
    <tr>
      <th>807</th>
      <td>Zeraora</td>
      <td>Electric</td>
      <td>NaN</td>
      <td>/pokedex/zeraora</td>
      <td>Thunderclap</td>
      <td>1.5</td>
      <td>44.5</td>
      <td>Volt Absorb</td>
      <td>3</td>
      <td>270</td>
      <td>Slow</td>
      <td>Genderless</td>
      <td>88.0</td>
      <td>112.0</td>
      <td>75.0</td>
      <td>102.0</td>
      <td>80.0</td>
      <td>143.0</td>
      <td>600.0</td>
      <td>[]</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    name                      0
    type_1                    0
    type_2                  402
    link                      0
    data_species              0
    data_height               0
    data_weight               0
    data_abilities            0
    training_catch_rate       0
    training_base_exp         0
    training_growth_rate      0
    breeding_gender           0
    stats_hp                  0
    stats_attack              0
    stats_defense             0
    stats_sp_atk              0
    stats_sp_def              0
    stats_speed               0
    stats_total               0
    percentages               0
    dtype: int64




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>type_1</th>
      <th>type_2</th>
      <th>link</th>
      <th>data_species</th>
      <th>data_height</th>
      <th>data_weight</th>
      <th>data_abilities</th>
      <th>training_catch_rate</th>
      <th>training_base_exp</th>
      <th>training_growth_rate</th>
      <th>breeding_gender</th>
      <th>stats_hp</th>
      <th>stats_attack</th>
      <th>stats_defense</th>
      <th>stats_sp_atk</th>
      <th>stats_sp_def</th>
      <th>stats_speed</th>
      <th>stats_total</th>
      <th>percentages</th>
    </tr>
    <tr>
      <th>id_nb</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Bulbasaur</td>
      <td>Grass</td>
      <td>Poison</td>
      <td>/pokedex/bulbasaur</td>
      <td>Seed</td>
      <td>0.7</td>
      <td>6.9</td>
      <td>Overgrow</td>
      <td>45</td>
      <td>64</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>45.0</td>
      <td>49.0</td>
      <td>49.0</td>
      <td>65.0</td>
      <td>65.0</td>
      <td>45.0</td>
      <td>318.0</td>
      <td>[87.5, 12.5]</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Ivysaur</td>
      <td>Grass</td>
      <td>Poison</td>
      <td>/pokedex/ivysaur</td>
      <td>Seed</td>
      <td>1.0</td>
      <td>13.0</td>
      <td>Overgrow</td>
      <td>45</td>
      <td>142</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>60.0</td>
      <td>62.0</td>
      <td>63.0</td>
      <td>80.0</td>
      <td>80.0</td>
      <td>60.0</td>
      <td>405.0</td>
      <td>[87.5, 12.5]</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Venusaur</td>
      <td>Grass</td>
      <td>Poison</td>
      <td>/pokedex/venusaur</td>
      <td>Seed</td>
      <td>2.0</td>
      <td>100.0</td>
      <td>Overgrow</td>
      <td>45</td>
      <td>236</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>80.0</td>
      <td>82.0</td>
      <td>83.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>80.0</td>
      <td>525.0</td>
      <td>[87.5, 12.5]</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Charmander</td>
      <td>Fire</td>
      <td>NaN</td>
      <td>/pokedex/charmander</td>
      <td>Lizard</td>
      <td>0.6</td>
      <td>8.5</td>
      <td>Blaze</td>
      <td>45</td>
      <td>62</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>39.0</td>
      <td>52.0</td>
      <td>43.0</td>
      <td>60.0</td>
      <td>50.0</td>
      <td>65.0</td>
      <td>309.0</td>
      <td>[87.5, 12.5]</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Charmeleon</td>
      <td>Fire</td>
      <td>NaN</td>
      <td>/pokedex/charmeleon</td>
      <td>Flame</td>
      <td>1.1</td>
      <td>19.0</td>
      <td>Blaze</td>
      <td>45</td>
      <td>142</td>
      <td>Medium Slow</td>
      <td>87.5% male, 12.5% female</td>
      <td>58.0</td>
      <td>64.0</td>
      <td>58.0</td>
      <td>80.0</td>
      <td>65.0</td>
      <td>80.0</td>
      <td>405.0</td>
      <td>[87.5, 12.5]</td>
    </tr>
  </tbody>
</table>
</div>



# Statistics


```python
cat_feat = list(df.select_dtypes(include=['object']).columns)
cat_feat = cat_feat[:-2]
cat_feat
```




    ['name',
     'type_1',
     'type_2',
     'link',
     'data_species',
     'data_abilities',
     'training_catch_rate',
     'training_base_exp',
     'training_growth_rate']




```python
num_feat = df.select_dtypes(include=['int64', 'float64']).columns#.remove('id_nb')
num_feat
```




    Index(['data_height', 'data_weight', 'stats_hp', 'stats_attack',
           'stats_defense', 'stats_sp_atk', 'stats_sp_def', 'stats_speed',
           'stats_total'],
          dtype='object')




```python
print(f"Pokemon's with a single type percentage = {df.type_2.isnull().sum()/df.shape[0]*100:.1f}%")
```

    Pokemon's with a single type percentage = 49.8%



```python
fig, ax = plt.subplots()
fig.set_size_inches(10, 8)
sns.boxplot(data=df, y="count", x="month_str", orient="v")
ax.set(xlabel="Months" , ylabel="Count", title="Count Across Month");
```


```python
sns.pairplot(df[num_feat])
```




    <seaborn.axisgrid.PairGrid at 0x7f73bad665f8>




![png](output_21_1.png)



```python
sns.set(style="white")

# Compute the correlation matrix
corr = df[num_feat].corr()

# Generate a mask for the upper triangle
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
f, ax = plt.subplots(figsize=(7, 6))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0, annot=True,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f73bad5e710>




![png](output_22_1.png)



```python
plt.figure(figsize=(18,25))
plt.subplot(521)

i=0
for c in cat_feat:
    plt.subplot(5, 2, i+1)
    i += 1
    sns.countplot(x=c, data=df, hue='training_growth_rate')
    plt.title(c)

plt.show()
```


![png](output_23_0.png)

